param(
    [string]$ArkApiKeyEnv = "llmkey-ark",
    [string]$CrsApiKeyEnv = "crs_oai_key",
    [string]$LiteLlmVenv = (Join-Path $env:LOCALAPPDATA "deepwiki-open\litellm-venv"),
    [int]$LiteLlmPort = 4000,
    [int]$Port = 8002,
    [ValidateSet("lmstudio", "ollama")]
    [string]$EmbeddingProvider = "lmstudio",
    [string]$EmbeddingBaseUrl = "http://127.0.0.1:1234/v1",
    [string]$EmbeddingModel = "text-embedding-qwen3-embedding-4b",
    [string]$EmbeddingApiKey = "lm-studio"
)

$ErrorActionPreference = "Stop"

$arkApiKey = [Environment]::GetEnvironmentVariable($ArkApiKeyEnv, "Process")
if ([string]::IsNullOrWhiteSpace($arkApiKey)) {
    $arkApiKey = [Environment]::GetEnvironmentVariable($ArkApiKeyEnv, "User")
}
if ([string]::IsNullOrWhiteSpace($arkApiKey)) {
    $arkApiKey = [Environment]::GetEnvironmentVariable($ArkApiKeyEnv, "Machine")
}

$crsApiKey = [Environment]::GetEnvironmentVariable($CrsApiKeyEnv, "Process")
if ([string]::IsNullOrWhiteSpace($crsApiKey)) {
    $crsApiKey = [Environment]::GetEnvironmentVariable($CrsApiKeyEnv, "User")
}
if ([string]::IsNullOrWhiteSpace($crsApiKey)) {
    $crsApiKey = [Environment]::GetEnvironmentVariable($CrsApiKeyEnv, "Machine")
}

if ([string]::IsNullOrWhiteSpace($arkApiKey)) {
    throw "Environment variable '$ArkApiKeyEnv' is not set."
}
if ([string]::IsNullOrWhiteSpace($crsApiKey)) {
    throw "Environment variable '$CrsApiKeyEnv' is not set."
}

if ($EmbeddingProvider -eq "ollama") {
    try {
        Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -TimeoutSec 3 | Out-Null
    } catch {
        throw "Ollama is not available at http://localhost:11434. Start Ollama before DeepWiki, or use -EmbeddingProvider lmstudio."
    }
} else {
    $modelsResponse = $null
    try {
        $modelsResponse = Invoke-RestMethod -Uri "$EmbeddingBaseUrl/models" -TimeoutSec 5
    } catch {
        throw "LM Studio embedding endpoint is not ready at $EmbeddingBaseUrl. Start LM Studio Local Server, load an embedding model, then retry. Detail: $($_.Exception.Message)"
    }
    $embeddingModelIds = @($modelsResponse.data | Select-Object -ExpandProperty id)
    if ($embeddingModelIds.Count -gt 0 -and $embeddingModelIds -notcontains $EmbeddingModel) {
        throw "LM Studio does not list embedding model '$EmbeddingModel'. Available models: $($embeddingModelIds -join ', ')"
    }
}

$env:LITELLM_ARK_API_KEY = $arkApiKey
$env:LITELLM_CRS_API_KEY = $crsApiKey
$env:LITELLM_MASTER_KEY = "sk-deepwiki-local"
$env:OPENAI_API_KEY = $env:LITELLM_MASTER_KEY
$env:OPENAI_BASE_URL = "http://127.0.0.1:$LiteLlmPort/v1"
if ($EmbeddingProvider -eq "ollama") {
    $env:DEEPWIKI_EMBEDDER_TYPE = "ollama"
} else {
    $env:DEEPWIKI_EMBEDDER_TYPE = "openai"
    $env:DEEPWIKI_EMBEDDING_BASE_URL = $EmbeddingBaseUrl
    $env:DEEPWIKI_EMBEDDING_API_KEY = $EmbeddingApiKey
    $env:DEEPWIKI_EMBEDDING_MODEL = $EmbeddingModel
}
$env:NODE_ENV = "production"
$env:PORT = $Port

$liteLlmExecutable = Join-Path $LiteLlmVenv "Scripts\litellm.exe"
if (-not (Test-Path -LiteralPath $liteLlmExecutable)) {
    Write-Host "Creating isolated LiteLLM Proxy environment at $LiteLlmVenv ..."
    python -m venv $LiteLlmVenv
    $liteLlmPython = Join-Path $LiteLlmVenv "Scripts\python.exe"
    & $liteLlmPython -m pip install "litellm[proxy]==1.83.10"
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to install the isolated LiteLLM Proxy environment."
    }
}

$liteLlmConfig = Join-Path $PSScriptRoot "litellm-config.yml"
$liteLlmJob = Start-Job -ScriptBlock {
    param($Executable, $ConfigPath, $ProxyPort)
    & $Executable --config $ConfigPath --port $ProxyPort
} -ArgumentList $liteLlmExecutable, $liteLlmConfig, $LiteLlmPort

try {
    $deadline = (Get-Date).AddSeconds(60)
    do {
        try {
            Invoke-RestMethod -Uri "http://127.0.0.1:$LiteLlmPort/health/liveliness" -TimeoutSec 2 | Out-Null
            break
        } catch {
            if ($liteLlmJob.State -in @("Failed", "Completed", "Stopped")) {
                Receive-Job -Job $liteLlmJob
                throw "LiteLLM stopped before becoming ready."
            }
            Start-Sleep -Milliseconds 500
        }
    } while ((Get-Date) -lt $deadline)

    if ((Get-Date) -ge $deadline) {
        throw "LiteLLM did not become ready on port $LiteLlmPort."
    }

    Write-Host "Model route: ark-code-latest -> https://ark.cn-beijing.volces.com/api/coding/v3"
    Write-Host "Model route: deepseek-v4-flash-260425 -> https://ark.cn-beijing.volces.com/api/coding/v3"
    Write-Host "Model route: crs -> http://47.101.159.7:39187/v1 (gpt5.5)"
    if ($EmbeddingProvider -eq "ollama") {
        Write-Host "Embedding: Ollama -> nomic-embed-text"
    } else {
        Write-Host "Embedding: LM Studio -> $EmbeddingBaseUrl ($EmbeddingModel)"
    }
    Write-Host "LiteLLM URL: http://localhost:$LiteLlmPort"
    Write-Host "Backend URL: http://localhost:$Port"
    Write-Host "API keys remain in process memory only."

    poetry -P api run python -m api.main
} finally {
    Stop-Job -Job $liteLlmJob -ErrorAction SilentlyContinue
    Remove-Job -Job $liteLlmJob -Force -ErrorAction SilentlyContinue
}
