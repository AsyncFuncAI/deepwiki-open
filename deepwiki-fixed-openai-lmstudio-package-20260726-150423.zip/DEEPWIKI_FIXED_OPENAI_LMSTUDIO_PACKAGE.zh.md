# DeepWiki 固定 OpenAI 路由 + LM Studio Embedding 迁移包说明

本包用于把另一个 `deepwiki-open` 工程配置成相同模式：

- 页面仍选择 `OpenAI` provider。
- 生成模型经本地 LiteLLM 转发。
- Embedding 默认走 LM Studio OpenAI-compatible API。

## 默认端口

```text
Frontend:  http://localhost:3000
Backend:   http://localhost:8002
LiteLLM:   http://localhost:4000
LM Studio: http://127.0.0.1:1234/v1
```

## 默认模型

生成模型：

```text
ark-code-latest
deepseek-v4-flash-260425
crs
```

Embedding 模型：

```text
text-embedding-qwen3-embedding-4b
```

本机已实测该 LM Studio 模型可返回 2560 维 embedding。

## 需要的环境变量

```text
llmkey-ark
crs_oai_key
```

不要把真实 Key 写入配置文件。本启动脚本只读取环境变量。

## 使用方法

1. 把压缩包解到目标 `deepwiki-open` 工程根目录，覆盖同名文件。
2. 在 LM Studio 启动 Local Server，端口 `1234`。
3. 加载 embedding 模型 `text-embedding-qwen3-embedding-4b`，或用 `/v1/models` 查到实际模型 ID。
4. 启动：

```powershell
.\start-fixed-openai-full.ps1
```

如果 LM Studio 模型 ID 不同：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingModel <实际模型id>
```

如果要临时切回 Ollama：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingProvider ollama
```

## 文件说明

- `run-fixed-openai.ps1`：启动 LiteLLM + 后端；读取 Key；设置生成和 embedding 环境变量。
- `start-fixed-openai-full.ps1`：完整一键启动前端、后端、LiteLLM。
- `litellm-config.yml`：固定模型路由。
- `api/config/generator.json`：OpenAI 下拉模型列表。
- `api/config/embedder.json`：LM Studio embedding 配置。
- `FIXED_OPENAI_USAGE.zh.md`：完整使用说明。
- `src/utils/websocketClient.ts` 和相关页面：修正前端 WebSocket 后端地址。
- `package.json`：关闭 Turbopack，避免旧 chunk 导致 WebSocket 地址不更新。
