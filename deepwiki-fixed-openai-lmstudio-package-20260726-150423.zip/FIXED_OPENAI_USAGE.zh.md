# DeepWiki 固定 OpenAI-compatible 路由使用说明

当前方案保持 DeepWiki 页面使用 `OpenAI` provider，不改业务调用路径。DeepWiki 后端仍请求本机 LiteLLM：

```text
http://127.0.0.1:4000/v1
```

LiteLLM 再按模型名路由到固定地址。

## 模型路由

| 页面选择 | 实际地址 | Key 环境变量 | 实际模型 |
| --- | --- | --- | --- |
| `OpenAI` / `ark-code-latest` | `https://ark.cn-beijing.volces.com/api/coding/v3` | `llmkey-ark` | `ark-code-latest` |
| `OpenAI` / `deepseek-v4-flash-260425` | `https://ark.cn-beijing.volces.com/api/coding/v3` | `llmkey-ark` | `deepseek-v4-flash-260425` |
| `OpenAI` / `crs` | `http://47.101.159.7:39187/v1` | `crs_oai_key` | `gpt5.5` |

`OpenAI` 这里只表示 OpenAI-compatible 协议，不表示真实供应商是 OpenAI。

## 一键启动

```powershell
cd D:\src\deepwiki-open
.\start-fixed-openai-full.ps1
```

脚本会自动：

1. 清理 `3000`、`4000`、`8002` 上的旧监听进程。
2. 启动 LiteLLM。
3. 启动 DeepWiki 后端。
4. 用 `SERVER_BASE_URL=http://localhost:8002` 和 `NEXT_PUBLIC_SERVER_BASE_URL=http://localhost:8002` 启动前端。
5. 验证 OpenAI 模型列表包含 `ark-code-latest`、`deepseek-v4-flash-260425`、`crs`。

打开：

```text
http://localhost:3000
```

## 只启动后端和 LiteLLM

```powershell
cd D:\src\deepwiki-open
.\run-fixed-openai.ps1
```

另开窗口启动前端：

```powershell
cd D:\src\deepwiki-open
cmd /c "set SERVER_BASE_URL=http://localhost:8002&& npm run dev"
```

如果手动启动前端，也建议同时设置浏览器端 WebSocket 地址：

```powershell
cmd /c "set SERVER_BASE_URL=http://localhost:8002&& set NEXT_PUBLIC_SERVER_BASE_URL=http://localhost:8002&& npm run dev"
```

## Embedding：默认 LM Studio

当前默认不再使用 Ollama，而是使用 LM Studio 的 OpenAI-compatible embeddings 接口：

```text
http://127.0.0.1:1234/v1
```

默认模型名：

```text
text-embedding-qwen3-embedding-4b
```

如果你在 LM Studio 里加载的 embedding 模型 ID 不同，先查看：

```powershell
Invoke-RestMethod http://127.0.0.1:1234/v1/models | ConvertTo-Json -Depth 5
```

然后用实际 `id` 启动：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingModel <LM-Studio模型id>
```

完整显式写法：

```powershell
.\start-fixed-openai-full.ps1 `
  -EmbeddingProvider lmstudio `
  -EmbeddingBaseUrl http://127.0.0.1:1234/v1 `
  -EmbeddingModel text-embedding-qwen3-embedding-4b `
  -EmbeddingApiKey lm-studio
```

LM Studio 侧需要：

1. 启动 Local Server，端口保持 `1234`。
2. 下载并加载一个 embedding 模型。
3. 确认 `/v1/models` 能看到该模型。

配置位置：

```text
api/config/embedder.json
```

所以生成 wiki 和 Ask 检索阶段不再依赖真实 OpenAI key。`OPENAI_API_KEY` 只在后端进程内设置为 LiteLLM 的本地 master key，用于访问 `http://127.0.0.1:4000/v1`。

如果要临时切回 Ollama：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingProvider ollama
```

Ollama 模型仍是：

```text
nomic-embed-text
```

## 修改位置

模型下拉列表：

```text
api/config/generator.json
```

LiteLLM 路由：

```text
litellm-config.yml
```

固定启动脚本：

```text
run-fixed-openai.ps1
start-fixed-openai-full.ps1
```
