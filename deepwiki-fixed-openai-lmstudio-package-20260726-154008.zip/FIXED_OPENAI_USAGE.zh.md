# DeepWiki 一键启动与模型配置说明

本工程当前采用“生成模型走 OpenAI-compatible 路径，Embedding 走本地 LM Studio”的配置。

关键点：页面里的 `OpenAI` 只是协议入口，不代表真实供应商一定是 OpenAI。后端请求本机 LiteLLM，LiteLLM 再按模型名转发到 Ark 或 CRS。

## 当前架构

```text
浏览器
  -> Frontend http://localhost:3000
  -> Backend  http://localhost:8002
  -> LiteLLM  http://127.0.0.1:4000/v1
      -> Ark / CRS 生成模型

Backend
  -> LM Studio http://127.0.0.1:1234/v1/embeddings
      -> 本地 embedding 模型
```

## 依赖内容

目标机器需要具备：

1. Windows PowerShell。
2. Python，并且能执行 `python -m venv`。
3. Poetry，本项目后端用：

```powershell
poetry -P api run python -m api.main
```

4. Node.js / npm，前端用：

```powershell
npx next dev --port 3000
```

5. LM Studio，默认用于 embedding。
6. 可选：Ollama，只在你指定 `-EmbeddingProvider ollama` 时需要。
7. 环境变量：

```text
llmkey-ark
crs_oai_key
```

脚本会读取这些环境变量，不会把 Key 写入配置文件。

## 默认端口

| 组件 | 地址 | 作用 |
| --- | --- | --- |
| Frontend | `http://localhost:3000` | 页面 |
| Backend | `http://localhost:8002` | DeepWiki API / WebSocket |
| LiteLLM | `http://localhost:4000` | 生成模型代理 |
| LM Studio | `http://127.0.0.1:1234/v1` | Embedding API |

## OpenAI 下拉模型的作用

页面选择 `OpenAI` provider 后，可以选择以下模型。这些模型用于：

- 生成 Wiki 页面内容。
- 生成 Ask 回答。
- 生成 Mermaid 图、解释、总结等文本。

它们不负责 embedding。

| 页面选择 | 实际供应商/地址 | Key 环境变量 | 实际模型 |
| --- | --- | --- | --- |
| `ark-code-latest` | `https://ark.cn-beijing.volces.com/api/coding/v3` | `llmkey-ark` | `ark-code-latest` |
| `deepseek-v4-flash-260425` | `https://ark.cn-beijing.volces.com/api/coding/v3` | `llmkey-ark` | `deepseek-v4-flash-260425` |
| `crs` | `http://47.101.159.7:39187/v1` | `crs_oai_key` | `gpt5.5` |

配置位置：

```text
api/config/generator.json
litellm-config.yml
```

启动脚本会设置：

```text
OPENAI_BASE_URL=http://127.0.0.1:4000/v1
OPENAI_API_KEY=sk-deepwiki-local
```

这里的 `OPENAI_API_KEY` 是本地 LiteLLM master key，不是真实 OpenAI Key。

## LM Studio 模型的作用

LM Studio 默认只用于 embedding，也就是：

- 读取本地仓库后，把代码/文档切成 chunk。
- 给 chunk 生成向量。
- Ask / 检索时用向量找相关代码片段。

它不负责生成最终 Wiki 文本，除非你以后另外把生成模型也改到 LM Studio。

当前默认 embedding 模型：

```text
text-embedding-qwen3-embedding-4b
```

本机已实测该模型可通过 LM Studio `/v1/embeddings` 返回 2560 维向量，适合中文、英文和代码混合检索。

LM Studio 需要：

1. 启动 Local Server。
2. 端口保持 `1234`。
3. 加载 embedding 模型。
4. 确认模型列表里有默认模型：

```powershell
Invoke-RestMethod http://127.0.0.1:1234/v1/models | ConvertTo-Json -Depth 5
```

如果你的模型 ID 不同，启动时指定：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingModel <实际模型id>
```

配置位置：

```text
api/config/embedder.json
```

相关环境变量由启动脚本设置：

```text
DEEPWIKI_EMBEDDER_TYPE=openai
DEEPWIKI_EMBEDDING_BASE_URL=http://127.0.0.1:1234/v1
DEEPWIKI_EMBEDDING_API_KEY=lm-studio
DEEPWIKI_EMBEDDING_MODEL=text-embedding-qwen3-embedding-4b
```

## Ollama 模型的作用

Ollama 是可选 embedding 回退方案。只有启动时指定下面参数才会用：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingProvider ollama
```

Ollama 当前使用：

```text
nomic-embed-text
```

它也只用于 embedding / 检索，不负责 Wiki 文本生成。

如果使用 Ollama，需要提前启动 Ollama 服务：

```text
http://localhost:11434
```

配置位置仍是：

```text
api/config/embedder.json
```

## 一键启动

默认使用 LM Studio embedding：

```powershell
cd D:\src\deepwiki-open
.\start-fixed-openai-full.ps1
```

脚本会自动：

1. 清理 `3000`、`4000`、`8002` 上的旧监听进程。
2. 检查 Ark / CRS 环境变量。
3. 检查 LM Studio `/v1/models` 是否可访问。
4. 启动 LiteLLM。
5. 启动 DeepWiki 后端。
6. 启动 Next.js 前端。
7. 验证页面 OpenAI 模型列表包含 `ark-code-latest`、`deepseek-v4-flash-260425`、`crs`。

打开：

```text
http://127.0.0.1:3000
```

如果浏览器无法打开 `localhost`，优先使用 `127.0.0.1`。

## 常用启动参数

指定 LM Studio embedding 模型：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingModel text-embedding-qwen3-embedding-4b
```

指定 LM Studio 地址：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingBaseUrl http://127.0.0.1:1234/v1
```

切换到 Ollama：

```powershell
.\start-fixed-openai-full.ps1 -EmbeddingProvider ollama
```

不清理旧端口进程：

```powershell
.\start-fixed-openai-full.ps1 -NoKill
```

只启动 LiteLLM + 后端：

```powershell
.\run-fixed-openai.ps1
```

## 文件说明

| 文件 | 作用 |
| --- | --- |
| `start-fixed-openai-full.ps1` | 一键启动前端、后端、LiteLLM，并设置 embedding |
| `run-fixed-openai.ps1` | 启动 LiteLLM + DeepWiki 后端 |
| `litellm-config.yml` | Ark / CRS 固定模型路由 |
| `api/config/generator.json` | 页面 OpenAI provider 的模型列表 |
| `api/config/embedder.json` | LM Studio / Ollama embedding 配置 |
| `src/utils/websocketClient.ts` | 前端 WebSocket 后端地址处理 |
| `package.json` | 前端启动命令，当前关闭 Turbopack |

## 快速自检

检查 LM Studio：

```powershell
Invoke-RestMethod http://127.0.0.1:1234/v1/models | ConvertTo-Json -Depth 5
```

检查 LiteLLM：

```powershell
Invoke-WebRequest http://127.0.0.1:4000/health/liveliness
```

检查后端：

```powershell
Invoke-WebRequest http://127.0.0.1:8002/health
```

检查前端：

```powershell
Invoke-WebRequest http://127.0.0.1:3000
```
